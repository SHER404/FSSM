 <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="assets/src/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/src/plugins/src/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="assets/src/plugins/src/mousetrap/mousetrap.min.js"></script>
    <script src="assets/src/plugins/src/waves/waves.min.js"></script>
    <script src="assets/layouts/modern-light-menu/app.js"></script>
   
    <script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>

    <!-- END GLOBAL MANDATORY SCRIPTS -->
    <script src="assets/src/plugins/src/table/datatable/datatables.js"></script>
    <script src="assets/src/plugins/src/table/datatable/button-ext/dataTables.buttons.min.js"></script>
    <script src="assets/src/plugins/src/table/datatable/button-ext/jszip.min.js"></script>    
    <script src="assets/src/plugins/src/table/datatable/button-ext/buttons.html5.min.js"></script>
    <script src="assets/src/plugins/src/table/datatable/button-ext/buttons.print.min.js"></script>
    <script src="assets/src/plugins/src/table/datatable/custom_miscellaneous.js"></script>
    <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->
    <script src="assets/src/plugins/src/apex/apexcharts.min.js"></script>
    <script src="assets/src/assets/js/dashboard/dash_1.js"></script>
    <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->
     <!-- BEGIN PAGE LEVEL SCRIPTS -->
  

    


      
