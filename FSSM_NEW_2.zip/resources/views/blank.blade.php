@extends('layout.layout')

@section('content')

            <div class="layout-px-spacing">

                <div class="middle-content container-xxl p-0">

                    <div class="row layout-top-spacing">

                        <h3>Blank Page</h3>

                    </div>
                </div>
            </div>

@endsection            