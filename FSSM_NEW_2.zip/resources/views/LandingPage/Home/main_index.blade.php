@include('LandingPage.Home.header')
@include('layout.includes.cssincludes_landing')
@include('LandingPage.Home.navbar')
@include('LandingPage.Home.herosection')
@include('LandingPage.Home.main')
@include('LandingPage.Home.ContactUs')
@include('layout.includes.jsincludes_landing')
@include('LandingPage.Home.footer')



