
<footer id="footer" class="footer">

  <div class="container">
    <div class="row gy-4">
      <div class="col-lg-5 col-md-12 footer-info">
        <a href="index.html" class="logo d-flex align-items-center">
          <span>Future Secure Sales and Marketing</span>
        </a>
        <p>The company FUTURE SECURE is working for those people who cannot afford their own business and searching for best platform with best plan.
        No matters what is age, education and gender.
        FUTURE SECURE make a common man personally and professionally very strong and make him able to earn money at home.
        </p>
        <div class="social-links d-flex mt-4">
          <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
          <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
          <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
          <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>

      <div class="col-lg-2 col-6 footer-links">
        <h4>Useful Links</h4>
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="#">About us</a></li>
          <li><a href="#">Services</a></li>
          <li><a href="#">Contact Us</a></li>
        </ul>
      </div>

      <div class="col-lg-2 col-6 footer-links">
        <h4>Our Services</h4>
        <ul>
          <li><a href="#">Marketing</a></li>
          <li><a href="#">Trading</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
    <h4>Contact Us</h4>
    <p>
        Tahsil Renala Khurd, District Okara <br><br>
        <strong>Phone:</strong>
        <a href="tel:(+92)3209450815">tel:(+92)3209450815</a>
        
          <br>
        <strong>Email:</strong> 
        <a href="mailto:admin@fs-sm.co">admin@fs-sm.co</a>
        <br>
    </p>
</div>


    </div>
  </div>

  <div class="container mt-4">
   
    <div class="credits">
   
      <!-- Designed by <a href="*">5Tech Sol.</a> -->
    </div>
  </div>

</footer>
</body>
</html>
