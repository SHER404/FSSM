
<!-- .......hero section.... -->
<section id="hero" class="d-flex align-items-center">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">
      <h1>You are warmly <span>welcome here</span></h1>
      <h2>Please check details latest news here</h2>
      <div class="d-flex">
        <a href="#about" class="btn-get-started scrollto">Get Started</a>
      </div>
    </div>
  </section>
  
  <!-- End Hero -->



