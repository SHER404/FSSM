
@extends('layout.layout')
@section('content')

<div class="layout-px-spacing">
	<div class="middle-content container-xxl p-0">

		<div class="col-xl-12 col-lg-12 col-sm-12 table">
			<div class="widget-content widget-content-area br-8 mt-4">
				<table id="zero-config" class="table dt-table-hover" style="width:100%;">
					<thead>
						<tr>
							<th>SL	</th>
							<th>Subject</th>
							<th>Status</th>
							<th>Last Reply</th>
							<th>Action</th>
							
						</tr>
					</thead>
					<tbody>
						<tr>
							<td colspan="5" style="text-align:center;">No data found</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

@endsection
