@extends('layout.layout')

@section('content')

<div class="layout-px-spacing">

<div class="middle-content container-xxl p-0">

<div class="row layout-top-spacing">

    <div class="shadow-lg p-3 mb-3 rounded Box">
        <h4 class="text-center text-white">Click here To download Fake IDS Elimination Policy</h4>
    </div>
    
    <div class="shadow-lg p-3 mb-3 rounded  Box-undertaking">
        <h4  class="text-center fw-light text-white">Click here To download UnderTaking Foe Underage</h4>
    </div>
        
    
        
    
        

</div>

</div>
</div>



@endsection